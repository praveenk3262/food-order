
           <!-- footer section starts -->
           
           <div class="footer">
            <div class="wrapper">
              <p class="text-center">2022 All rights reserved. Developed By - <a href="#">Dupati Karthik</a></p>
            </div>
        </div>
            <!-- footer section ends -->
    </body>
</html>